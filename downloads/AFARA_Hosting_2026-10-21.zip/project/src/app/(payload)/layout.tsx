import config from '@payload-config'
import '@payloadcms/next/css'
import '@/cms/admin.css'
import type { ServerFunctionClient } from 'payload'
import { handleServerFunctions, RootLayout } from '@payloadcms/next/layouts'
import { importMap } from './admin/importMap.js'
export const viewport = {width:'device-width',initialScale:1}
const serverFunction: ServerFunctionClient = async function (args) {
  'use server'
  return handleServerFunctions({...args,config,importMap})
}
export default function Layout({children}:{children:React.ReactNode}) {
  return <RootLayout config={config} importMap={importMap} serverFunction={serverFunction}>{children}</RootLayout>
}
